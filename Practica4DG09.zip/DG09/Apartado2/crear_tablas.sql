    CREATE TABLE Empleados (
    Nombre CHAR(50) NOT NULL,
    DNI CHAR(9) PRIMARY KEY,
    Sueldo NUMBER(6,2),
    CHECK (Sueldo BETWEEN 735.90 AND 5000.00));
 
    create table Domicilios(
    DNI char(9) REFERENCES Empleados ON DELETE CASCADE, 
    Calle char(50), 
    "C�digo postal" char(5), 
    primary key (DNI, Calle, "C�digo postal"),
    foreign key (DNI)REFERENCES Empleados(DNI),
    foreign key ("C�digo postal") REFERENCES "C�digos postales"("C�digo postal")
    );
    
    CREATE TABLE Tel�fonos
    (DNI CHAR(9) REFERENCES Empleados ON DELETE CASCADE,
    Tel�fono CHAR(9),
    PRIMARY KEY (DNI, Tel�fono),
    foreign key (DNI) references Empleados(DNI)
    );
    
    create table "C�digos postales"(
    "C�digo postal" Char(5), 
    Poblaci�n Char(50), 
    Provincia Char(50), 
    primary key("C�digo postal")
    );
    
    --Table EMPLEADOS creado.
    --Table "C�digos postales" creado.
    --Table DOMICILIOS creado.
    --Table TEL�FONOS creado.
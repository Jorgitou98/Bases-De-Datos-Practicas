--1)Inserci�n de una fila con clave primaria duplicada
insert into Empleados values('Juan', '123456789', 1000);
insert into Empleados values('Pedro', '123456789', 1500);

--Error que empieza en la l�nea: 2 del comando :
--insert into Empleados values('Pedro', '123456789', 1500)
--Informe de error -
--ORA-00001: restricci�n �nica (DG09.SYS_C0011912) violada
---------------------------------------------------------------

--2)Inserci�n que no incluya todas las columnas que requieren un valor

insert into Tel�fonos values ('925111111');

--Error que empieza en la l�nea: 12 del comando -
--insert into Tel�fonos values ('925111111')
--Error en la l�nea de comandos : 12 Columna : 13
--Informe de error -
--Error SQL: ORA-00947: no hay suficientes valores
--00947. 00000 -  "not enough values"
--*Cause:    
--*Action:
-------------------------------------------------------------

--3)Inserci�n que no verifique las restricciones de dominio CHECK.

insert into Empleados values ('Luis', '987654321', 700);

--Error que empieza en la l�nea: 25 del comando :
--insert into Empleados values ('Luis', '987654321', 700)
--Informe de error -
--ORA-02290: restricci�n de control (DG09.SYS_C0011911) violada
-----------------------------------------------------------------

--4)Inserci�n que no respete una regla de integridad referencial

insert into Tel�fonos values('999999999', '910000000');

--Error que empieza en la l�nea: 32 del comando :
--insert into Tel�fonos values('999999999', '910000000')
--Informe de error -
--ORA-02291: restricci�n de integridad (DG09.SYS_C0011920) violada - clave principal no encontrada

--5)Borrado en una tabla padre con filas dependientes donde la FK tiene una regla de borrado ON DELETE NO ACTION

insert into "C�digos postales" values('45760', 'La Guardia', 'Toledo');
insert into Domicilios values('123456789', 'Mayor', '45760');

delete from "C�digos postales" where "C�digo postal" = '45760';

--1 fila insertadas.
--
--
--1 fila insertadas.
--
--
--Error que empieza en la l�nea: 49 del comando :
--delete from "C�digos postales" where "C�digo postal" = '45760'
--Informe de error -
--ORA-02292: restricci�n de integridad (DG09.SYS_C0011917) violada - registro secundario encontrado
--6) Borrado en una tabla padre con filas dependientes donde la FK tiene una regla de borrado ON
--DELETE CASCADE. Por ejemplo, borra un empleado y documenta lo que sucede con sus tel�fonos
--y direcciones.
insert into Empleados values ('Pepe', '51195258H', 800);
insert into Tel�fonos values('51195258H', '910000010');
insert into Domicilios values('51195258H', 'Mayor 1', '45760');

delete from Empleados where DNI = '51195258H';

select * from Tel�fonos where DNI = '51195258H';
select * from Domicilios where DNI = '51195258H';

--Nos devuelve una tabla vac�a

--7)Borrado en Empleados cuando Tel�fonos tiene una regla de borrado ON DELETE SET NULL sobre
--el campo DNI.
CREATE TABLE Tel�fonos2
    (DNI CHAR(9) REFERENCES Empleados ON DELETE SET NULL,
    Tel�fono CHAR(9),
    PRIMARY KEY (DNI, Tel�fono),
    Foreign KEY (DNI) REFERENCES Empleados(DNI)
    );
insert into Tel�fonos2 values('123456789', '925138006');
delete from Empleados  where DNI = '123456789';

select * from Tel�fonos2 where Tel�fono = '925138006';

drop table Tel�fonos2;

--Error que empieza en la l�nea: 81 del comando :
--delete from Empleados  where DNI = '123456789'
--Informe de error -
--ORA-01407: no se puede actualizar ("CC09"."TEL�FONOS2"."DNI") a un valor NULL
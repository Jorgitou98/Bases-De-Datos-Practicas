/abolish
/multiline on
/duplicates on

create table Empleados(Nombre string, DNI string primary key, Sueldo int);

create table Domicilios(DNI string, Calle string, "C�digo postal" string, primary key(DNI, Calle, "C�digo postal"));

create table Tel�fonos(DNI string, Tel�fono string, primary key (DNI, Tel�fono));

create table "C�digos postales"("C�digo postal" string primary key, Poblaci�n string, Provincia string);


insert into Empleados values('Antonio Arjona', '12345678A', 5000);
insert into Empleados values('Carlota Cerezo', '12345678C', 1000);
insert into Empleados values('Laura L�pez', '12345678L', 1500);
insert into Empleados values('Pedro P�rez', '12345678P', 2000);

insert into "C�digos postales" values ('08050', 'Parets', 'Barcelona');
insert into "C�digos postales" values ('14200', 'Pe�arroya', 'C�rdoba');
insert into "C�digos postales" values ('14900', 'Lucena', 'C�rdoba');
insert into "C�digos postales" values ('28040', 'Madrid', 'Madrid');
insert into "C�digos postales" values ('50008', 'Zaragoza', 'Zaragoza');
insert into "C�digos postales" values ('28004', 'Arganda', 'Madrid');

insert into Tel�fonos values ('12345678C', '611111111');
insert into Tel�fonos values ('12345678C', '931111111');
insert into Tel�fonos values ('12345678L', '913333333');
insert into Tel�fonos values ('12345678P', '913333333');
insert into Tel�fonos values ('12345678P', '644444444');

insert into Domicilios values('12345678A','Avda. Complutense', '28040');
insert into Domicilios values('12345678A','C�ntaro', '28004');
insert into Domicilios values('12345678P','Diamante', '14200');
insert into Domicilios values('12345678P','Carb�n', '14900');
insert into Domicilios values('12345678L','Diamante', '14200');


-- Vista 1

create view vista1(Nombre, Calle, "C�digo Postal") as select Nombre, Calle, "C�digo postal" from Empleados natural join Domicilios order by "C�digo postal", Nombre;

select * from vista1;

--Vista 2

create view vista2(Nombre, DNI, Calle, "Codigo postal", Tel�fono) as select Nombre, DNI, Calle, "C�digo postal", Tel�fono from (Empleados natural left outer join Domicilios) natural join Tel�fonos order by Nombre;
select * from vista2;


-- Vista 3

create view vista3(Nombre, DNI, Calle, "C�digo postal", Tel�fono) as select Nombre, DNI, Calle, "C�digo postal", Tel�fono from (Empleados natural left outer join Domicilios) natural left outer join Tel�fonos order by Nombre;

select * from vista3;

--Vista 4

create view vista4(Nombre, DNI, Calle, Poblaci�n, Provincia, "C�digo postal") as select Nombre, DNI, Calle, Poblaci�n, Provincia, "C�digo postal" from Empleados natural left outer join (Domicilios natural join "C�digos postales") order by Nombre;

select * from vista4;


--Vista 5

create view vista5(Nombre, DNI, Calle, Poblaci�n, Provincia, "C�digo postal", Tel�fono) as select Nombre, DNI, Calle, Poblaci�n, Provincia, "C�digo postal", Tel�fono from (Empleados natural left outer join (Domicilios natural join "C�digos postales")) natural left outer join Tel�fonos order by Nombre;

select * from vista5;

-- Vista 6

update Empleados set Sueldo = floor(1.1 * Sueldo) where Sueldo * 1.1 <= 1900.0;

select * from Empleados;

-- Vista 7

update Empleados set Sueldo = ceiling(Sueldo / 1.1) where Sueldo <= 1900;

select * from Empleados;

-- Vista 8

update Empleados set Sueldo = floor(1.1 * Sueldo) where Sueldo * 1.1 <= 1600.0;

select * from Empleados;

update Empleados set Sueldo = ceiling(Sueldo/1.1) where Sueldo <= 1600;

select * from Empleados;

--La tabla original no recupera sus valores primitivos, pues el sueldo con valor 1500 no se puede saber si se quedo sin actualizar o si ya estaba actualizado, por lo que se le devuelve a un supuesto valor original al que supuestamente se le sum� un 10%, algo que no es as�, pero no hay ninguna manera por medio de las instrucciones sql y del ��gebra relacional estudiadas, que no impliquen el guardado en una tabla auxiliar de los datos originales, que nos permitan saber si ese dato que es menor que 1600 se actualiz� o no.

--Restablecemos el valor original "a mano":

update Empleados set Sueldo = floor(Sueldo * 1.1) where DNI = '12345678L';

select * from Empleados;

-- Vista 9

create view vista9(Empleados, "Sueldo m�nimo", "Sueldo m�ximo", "Sueldo medio") as select count(*), min(Sueldo), max(Sueldo), floor(avg(Sueldo)) from Empleados;

select * from vista9;

-- Vista 10 (Resuelto con la interpretaci�n (a) de la hoja de resultados)

create view vista10 ("Sueldo medio", "N�mero empleados", Poblaci�n) as select floor(avg(Sueldo)), count(DNI), Poblaci�n from Empleados natural left outer join (Domicilios natural join "C�digos postales") group by Poblaci�n order by Poblaci�n;

select * from vista10;

-- Vista 11

create view vista11(Nombre, DNI, Tel�fono) as select a.Nombre, a.DNI, a.Tel�fono from (Empleados natural join Tel�fonos) a where (select count(*) from Tel�fonos where a.DNI = DNI) > 1 order by a.Nombre;


select * from vista11;
